import React from 'react';
import { Link } from 'react-router-dom';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Input from '@material-ui/core/Input';
import Paper from '@material-ui/core/Paper';
import withStyles from '@material-ui/core/styles/withStyles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

import styles from './styles';

const firebase = require('firebase');

const INPUT_TYPES = {
	EMAIL: 'email',
	PASSWORD: 'password',
	PASSWORD_CONFIRM: 'passwordConfirmation'
};

class SingUpComponent extends React.Component {
	constructor() {
		super();

		this.state = {
			email: null,
			password: null,
			passwordConfirmation: null,
			signupError: ''
		};
	}

	isFormValid = () => this.state.password === this.state.passwordConfirmation;

	submitSignup = (event) => {
		const { email, password } = this.state;
		event.preventDefault();

		if (!this.isFormValid()) {
			this.setState({
				signupError: 'Passwords do not match!',
				password: null,
				passwordConfirmation: null
			});
			return;
		}

		// create user in Auth service and then save to db
		firebase.auth().createUserWithEmailAndPassword(email, password).then(
			(authRes) => {
				const userObj = {
					email: authRes.user.email
				};
				firebase.firestore().collection('users').doc(email).set(userObj).then(
					() => {
						this.props.history.push('/dashboard');
					},
					(dbError) => {
						this.setState({
							signupError: 'Failed to save user!'
						});
					}
				);
			},
			(authError) => {
				console.log(authError);
				this.setState({
					signupError: authError.message
				});
			}
		);
	};

	userTyping = (type, event) => {
		switch (type) {
			case INPUT_TYPES.EMAIL:
				this.setState({
					email: event.target.value
				});
				break;
			case INPUT_TYPES.PASSWORD:
				this.setState({
					password: event.target.value
				});
				break;
			case INPUT_TYPES.PASSWORD_CONFIRM:
				this.setState({
					passwordConfirmation: event.target.value
				});
				break;
			default:
				break;
		}
	};

	render() {
		const { signupError } = this.state;
		const { classes } = this.props;

		return (
			<main className={classes.main}>
				<CssBaseline />
				<Paper className={classes.paper}>
					<Typography component="h1" variant="h5">
						Sign up!
					</Typography>
					<form
						className={classes.form}
						onSubmit={(event) => {
							this.submitSignup(event);
						}}
					>
						<FormControl required fullWidth margin="normal">
							<InputLabel htmlFor="signup-email-input">Enter your email</InputLabel>
							<Input
								autoComplete="email"
								autoFocus
								id="signup-email-input"
								onChange={(event) => this.userTyping(INPUT_TYPES.EMAIL, event)}
							/>
						</FormControl>
						<FormControl required fullWidth margin="normal">
							<InputLabel htmlFor="signup-password-input">Create a password</InputLabel>
							<Input
								type="password"
								id="signup-password-input"
								onChange={(event) => this.userTyping(INPUT_TYPES.PASSWORD, event)}
							/>
						</FormControl>
						<FormControl required fullWidth margin="normal">
							<InputLabel htmlFor="signup-password-confirmation-input">Confirm password</InputLabel>
							<Input
								type="password"
								id="signup-password-confirmation-input"
								onChange={(event) => this.userTyping(INPUT_TYPES.PASSWORD_CONFIRM, event)}
							/>
						</FormControl>
						<Button type="submit" fullWidth variant="contained" color="primary" className={classes.submit}>
							Submit
						</Button>
					</form>
					{signupError && (
						<Typography component="h5" variant="h6" className={classes.errorText} key="signupError">
							{signupError}
						</Typography>
					)}
					<Typography component="h5" variant="h6" className={classes.hasAccountHeader}>
						Already have an account?
					</Typography>
					<Link className={classes.logInLink} to="/login">
						Log in!
					</Link>
				</Paper>
			</main>
		);
	}
}

export default withStyles(styles)(SingUpComponent);
