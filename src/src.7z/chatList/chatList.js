import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import Typography from '@material-ui/core/Typography';
import styles from './styles';
import Divider from '@material-ui/core/Divider';
import Button from '@material-ui/core/Button';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import NotificationImportant from '@material-ui/icons/NotificationImportant';

class ChatList extends React.Component {
	selectChat = (index) => {
		this.props.selectChatFn(index)
	};

	render() {
		const { classes } = this.props;

		if (this.props.chats && this.props.chats.length === 0) return null;

		return (
			<main className={classes.root}>
				<Button
					variant="contained"
					fullWidth
					color="primary"
					className={classes.newChatBtn}
					onClick={this.newChat}
				>
					New chat
				</Button>
				<List>
					{this.props.chats.map((_chat, index) => {
						const friendsName = _chat.users.filter((_user) => _user !== this.props.userEmail)[0];
						const message = _chat.messages[_chat.messages.length - 1].message.substring(0, 30);
						return (
							<div key={`index_${index}`}>
								<ListItem
									onClick={() => this.selectChat(index)}
									className={classes.listItem}
									selected={this.props.selectedChatIndex === index}
									alignItems="flex-start"
								>
									<ListItemAvatar>
										<Avatar alt="Remy Sharp">{friendsName.split('')[0]}</Avatar>
									</ListItemAvatar>
									<ListItemText
										primary={friendsName}
										secondary={
											<React.Fragment>
												<Typography component="span" color="textPrimary">
													{`${message}...`}
												</Typography>
											</React.Fragment>
										}
									/>
								</ListItem>
								<Divider />
							</div>
						);
					})}
				</List>
			</main>
		);
	}
}

export default withStyles(styles)(ChatList);
