import React from 'react';
import TextField from '@material-ui/core/TextField';
import Send from '@material-ui/icons/Send';
import styles from './styles';
import { withStyles } from '@material-ui/core/styles';

const ENTER_BTN_KEY = 13;

class ChatTextBox extends React.Component {
	constructor() {
		super();
		this.state = {
			chatText: ''
		};
	}

	userTyping = (event) => {
		if (event.keyCode === ENTER_BTN_KEY) {
			this.submitMessage();
			return null;
		}
		this.setState({
			chatText: event.target.value
		});
	};

	messageValid = (text) => text && text.replace(/\s/g, '').length;

	userClickedInput = () => {
		console.log('Clicked input');
	};

	submitMessage = () => {
		if (this.messageValid(this.state.chatText)) {
            this.props.submitMessageFn(this.state.chatText)
			document.getElementById('chatBoxTextFiled').value = '';
		}
	};

	render() {
		const { classes } = this.props;

		return (
			<div className={classes.chatTextBoxContainer}>
				<TextField
					placeholder="Type your message..."
					onKeyUp={(event) => {
						this.userTyping(event);
					}}
					id="chatBoxTextFiled"
					className={classes.chatTextBox}
					onFocus={this.userClickedInput}
				/>
				<Send onClick={this.submitMessage} className={styles.sendBtn} />
			</div>
		);
	}
}

export default withStyles(styles)(ChatTextBox);
