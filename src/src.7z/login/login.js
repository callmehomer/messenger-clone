import React from 'react';
import { Link } from 'react-router-dom';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Input from '@material-ui/core/Input';
import Paper from '@material-ui/core/Paper';
import withStyles from '@material-ui/core/styles/withStyles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

import styles from './styles';

const firebase = require('firebase');

const INPUT_TYPES = {
	EMAIL: 'email',
	PASSWORD: 'password'
};

class LoginComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			email: null,
			password: null,
			loginError: ''
		};
	}
	submitLogin = (event) => {
		const { email, password } = this.state;
		event.preventDefault();
		firebase.auth().signInWithEmailAndPassword(email, password).then(
			() => {
				this.props.history.push('/dashboard');
			},
			(err) => {
				this.setState({ loginError: err.message });
				console.log(err);
			}
		);
	};

	userTyping = (type, event) => {
		switch (type) {
			case INPUT_TYPES.EMAIL:
				this.setState({
					email: event.target.value
				});
				break;
			case INPUT_TYPES.PASSWORD:
				this.setState({
					password: event.target.value
				});
				break;
			default:
				break;
		}
	};

	render() {
		const { loginError } = this.state;
		const { classes } = this.props;
		return (
			<main className={classes.main}>
				<CssBaseline />
				<Paper className={classes.paper}>
					<Typography component="h1" variant="h5">
						Log in!
					</Typography>
					<form className={classes.form} onSubmit={(event) => this.submitLogin(event)}>
						<FormControl required fullWidth margin="normal">
							<InputLabel htmlFor="login-email-input">Enter your email</InputLabel>
							<Input
								autoComplete="email"
								autoFocus
								id="login-email-input"
								onChange={(event) => {
									this.userTyping(INPUT_TYPES.EMAIL, event);
								}}
							/>
						</FormControl>
						<FormControl required fullWidth margin="normal">
							<InputLabel htmlFor="login-password-input">Enter your password</InputLabel>
							<Input
								id="login-password-input"
								type="password"
								onChange={(event) => {
									this.userTyping(INPUT_TYPES.PASSWORD, event);
								}}
							/>
						</FormControl>
						<Button type="submit" fullWidth variant="contained" color="primary" className={classes.submit}>
							Log in!
						</Button>
					</form>
					{loginError && (
						<Typography component="h5" variant="h6" className={classes.errorText} key="loginError">
							{loginError}
						</Typography>
					)}
					<Typography component="h5" variant="h6" className={classes.noAccountHeader}>
						Don't have an account?
					</Typography>
					<Link className={classes.signUpLink} to="/signup">
						Sign up!
					</Link>
				</Paper>
			</main>
		);
	}
}

export default withStyles(styles)(LoginComponent);
