import React from 'react';
import ChatList from '../chatList/chatList';
import ChatView from '../chatView/chatView';
import ChatTextBox from '../chatTextBox/chatTextBox';
import { Button, withStyles } from '@material-ui/core';
import styles from './styles';
const firebase = require('firebase');

class DashboardComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			selectedChat: null,
			newChatFormVisible: false,
			email: null,
			chats: []
		};
	}

	componentWillMount = () => {
		firebase.auth().onAuthStateChanged(async (_usr) => {
			if (!_usr) this.props.history.push('/login');
			else {
				await firebase
					.firestore()
					.collection('chats')
					.where('users', 'array-contains', _usr.email)
					.onSnapshot(async (res) => {
						const chats = res.docs.map((_doc) => _doc.data());
						await this.setState({
							email: _usr.email,
							chats: chats
						});
						console.log(this.state);
					});
			}
		});
	};

	newChatBtnClicked = () => {
		this.setState({
			newChatFormVisible: true,
			selectedChat: null
		});
	};

	selectChat = (chatIndex) => {
		this.setState({
			selectedChat: chatIndex
		});
	};

	buildDocKey = (friend) => [ this.state.email, friend ].sort().join(':');

	submitMessage = (message) => {
		const friend = this.state.chats[this.state.selectedChat].users.filter((_usr) => _usr !== this.state.email)[0];
		const docKey = this.buildDocKey(friend);
		console.log(docKey);
		firebase.firestore().collection('chats').doc(docKey).set(
			{
				messages: firebase.firestore.FieldValue.arrayUnion({
					sender: this.state.email,
					message: message,
					timestamp: Date.now()
				}),
				receiverHasRead: false
			},
			{ merge: true }
		);
	};

	signOut = () => firebase.auth().signOut();

	render() {
		const { selectedChat, email, chats, newChatFormVisible } = this.state;
		const { classes } = this.props;

		return (
			<div>
				<ChatList
					history={this.props.history}
					newChatBtnFn={this.newChatBtnClicked}
					selectChatFn={this.selectChat}
					chats={chats}
					userEmail={email}
					selectedChatIndex={selectedChat}
				/>
				{selectedChat !== null &&
				!newChatFormVisible && <ChatTextBox key="chatTextBox" submitMessageFn={this.submitMessage} />}
				<Button onClick={this.signOut} className={classes.signOutBtn}>
					Sign out
				</Button>
				{selectedChat !== null && <ChatView user={email} chat={chats[selectedChat]} key="chatView" />}
			</div>
		);
	}
}

export default withStyles(styles)(DashboardComponent);
